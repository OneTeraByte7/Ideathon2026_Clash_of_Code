import requests

BOT_TOKEN = "8795379419:AAG_fiiluEx-GQI1bHyisFaNuVxzsIMBFo8"
CHAT_ID = "5563183227"

def send_telegram_alert(message, patient_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

    data = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "Markdown",
        "reply_markup": {
            "inline_keyboard": [
                [
                    {"text": "✅ Approve", "callback_data": f"approve_{patient_id}"},
                    {"text": "❌ Reject", "callback_data": f"reject_{patient_id}"}
                ],
                [
                    {"text": "✏️ Modify", "callback_data": f"modify_{patient_id}"}
                ]
            ]
        }
    }

    requests.post(url, json=data)